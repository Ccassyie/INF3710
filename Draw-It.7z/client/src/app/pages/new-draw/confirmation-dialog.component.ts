import { Component } from '@angular/core';

@Component({
  templateUrl: 'confirmation-dialog.component.html'
})
export class ConfirmationDialogComponent {}
