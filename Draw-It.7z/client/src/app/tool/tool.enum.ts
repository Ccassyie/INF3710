export enum Tool {
  Brush,
  Color,
  Eraser,
  Line,
  Pencil,
  Rectangle,
  _Len,
  _None,
}
