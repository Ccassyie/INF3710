DrawIt vous offre la possibilité d’activer ou de désactiver une grille pour faciliter le traçage de formes.

 Vous pouvez acccéder à la grille //TODO et vous pouvez la désactiver //TODO. Il est possible d’ajuster l’opacité ainsi que la taille des carreaux de la grille.