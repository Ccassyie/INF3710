L'outil **Aérosol** permet de simuler l’utilisation d’une bombe de peinture aérosol. Pour commencer à utiliser l’aérosol, cliquez sur l’icône . Son utilisation est semblable à celle du crayon : pressez le clic gauche de votre souris afin de commencer à dessiner, et déplacez votre souris sur la zone de dessin en gardant le bouton enfoncé. Relâchez le bouton gauche lorsque vous avez terminé de dessiner. 

 Vous avez la possibilité d’ajuster la densité du jet de peinture avec le premier _slider_ du panneau de configuration, ainsi que le diamètre du jet avec le second _slider_.
