En cliquant sur le bouton `Guide d’utilisation`, vous accédez à ce guide. 

<img class="doc-img" alt="image du guide d'utilisation" title="Le guide d'utilisation de DrawIt" src="../../assets/doc/imgs/doc-docPopup.png" width="80%">

 Vous pouvez également accéder au guide en tout temps depuis la zone de dessin en cliquant sur l’icône ![icône doc](../../assets/gimp-prefs-help-system.svg). 
