L’outil **Crayon** est l’outil le plus basique de DrawIt. Il vous permet de tracer des formes quelconques. 

<img class="doc-img" src="../../assets/doc/imgs/doc-outilCrayon.png" title="Exemple de motif réalisé à l'aide de l'outil Crayon" alt="image outil crayon" width="100%">

Pour utiliser l’outil, cliquez sur l’icône ![crayon](../../assets/gimp-tool-pencil.png), ou appuyez sur la touche **`C`** de votre clavier, et placez votre curseur sur la zone de dessin. En maintenant le bouton gauche de votre souris enfoncé, déplacez votre curseur dans la zone de dessin pour faire une forme. Relâchez le bouton gauche de la souris pour arrêter de dessiner.

Le panneau de cet outil vous permet de régler en pixels l'épaisseur du trait créé. 
