L’outil **Gomme** permet d’effacer des objets de la zone de dessin.

 Pour utiliser l’outil Gomme, cliquez sur l’icône  . Placez votre curseur sur un objet de la zone de dessin pour avoir un aperçu de l’objet qui va être effacé. Pour effacer un objet, effectuer un simple clic gauche sur l’objet désiré. Vous pouvez également maintenir le clic gauche et effectuer un glissé-déposé afin d’effacer plusieurs objets.

 Le panneau d’options de l’outil Gomme vous permet de régler l’épaisseur de la gomme en pixels.
