doc exportation de dessin (options d'exportations, etc)
