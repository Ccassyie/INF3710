DrawIt possède une option **Magnétisme** dont le but est de faciliter le déplacement et l’alignement des objets de la zone de dessin.

 Vous pouvez activer et désactiver le magnétisme //TODO. Le magnétisme se base sur les carreaux de la grille pour « attirer » les formes. En ajustant la taille des carreaux de la grille, vous modifierez également le comportement du magnétisme.
