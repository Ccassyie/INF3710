L’outil **Pipette** sert à sélectionner des couleurs à partir d’une image. Pour utiliser l’outil Pipette, commencez par cliquer sur l’icône . 

Effectuez un clic gauche pour remplacer la couleur principale par la couleur du pixel cliqué. Effectuez un clic droit pour remplacer la couleur secondaire par celle du pixel cliqué.
