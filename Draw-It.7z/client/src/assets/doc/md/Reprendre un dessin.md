Si vous avez déjà utilisé DrawIt auparavant, vous aurez accès à deux options supplémentaires sur le menu principal : `Aller à la Galerie` et `Continuer un ancien dessin`. 

 Le premier bouton affichera les anciens dessins que vous avez pu créer précédemment, en vous présentant un aperçu pour chacun d’eux. Cliquez sur un aperçu pour l’ouvrir et le modifier.

 Le second bouton chargera automatiquement le dernier dessin modifié.
