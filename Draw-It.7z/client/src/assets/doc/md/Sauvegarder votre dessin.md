doc sauvegarde du dessin

*   sauvegarde manuelle
*   sauvegarde automatique
