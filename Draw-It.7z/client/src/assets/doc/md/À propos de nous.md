<img class="doc-img" src="../../assets/doc/imgs/NOUS.jpg" title="L'équipe" alt="image de l'équipe" width="100%">

L'équipe **Françafrique**, de gauche à droite :

* Samba Bal
* Mathurin Chritin
* Hubert Grootenboer
* Issam Maghni
* Nicolas Verbaere
* Augustin Sangam

Cette application a été développée dans le cadre du cours de LOG2990 « Projet logiciel d'application Web », donné en deuxième année dans le département de génie informatique et logiciel à l'École Polytechnique de Montréal.

Professeurs responsables : 
* Lévis Thériault
* Nikolay Radoev
