L’outil **Étampe** vous permet d’appliquer des petites images prédéfinies comme des _cliparts_ ou des _emojis_. Pour utiliser l’outil Étampe, commencez par cliquer sur l’icône . Placez votre curseur sur la zone de dessin et faites un clic gauche pour appliquer une étampe. 

Pour sélectionner l’étampe à appliquer, rendez vous dans la section `Choix d’étampe` du panneau d’options de l’outil. Vous pouvez également régler l’orientation de l’étampe à appliquer depuis le panneau d’options. 

 Il est également possible de régler l’orientation de la même manière que pour l’outil plume, soit en faisant varier la molette de votre souris. En appuyant sur la touche `ALT`, vous pourrez effectuer un réglage fin de l’orientation de l’étampe. 

 Enfin, vous pourrez régler la taille de l’étampe avec le _slider_ `Mise à l’échelle`.
