const TYPES = {
	ThrowableWeapon: Symbol.for('ThrowableWeapon'),
	Warrior: Symbol.for('Warrior'),
	Weapon: Symbol.for('Weapon'),
};

export { TYPES };
